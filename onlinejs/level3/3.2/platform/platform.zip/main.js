const os = require('node:os');
const platform = os.platform();
console.log(platform);